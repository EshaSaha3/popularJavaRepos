package com.musa.popularrepo.Repos

import androidx.lifecycle.ViewModel

class ReposViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}
