package com.musa.popularrepo

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.musa.popularrepo.base.LoadingCallback

class MainActivity : AppCompatActivity() , LoadingCallback {
    override fun showLoading() {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    override fun showLoading(resId: Int) {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    override fun dismissLoading() {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    override fun showError(message: String) {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        setUpNavigation()
    }

    private fun setUpNavigation() {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }
}
